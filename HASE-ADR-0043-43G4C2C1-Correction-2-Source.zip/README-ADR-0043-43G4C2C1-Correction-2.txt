HASE ADR-0043 Increment 43G4C2C1 Correction 2 source overlay.
Apply after Correction 1 over the repository root, build Release, and run the
full suite. Expected result: 4,373 tests passed.
The correction adds the missing PropertyId namespace import to C-020.
