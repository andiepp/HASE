# ADR-0035 Increment 5 — Explicit Parameterless Command Execution

## Status

Implemented for validation.

## Scope

The Desktop Runtime Host operator console can now execute explicitly selected
parameterless Commands.

Each Command inventory snapshot carries:

- the complete normalized `RuntimeHostCommandTarget`;
- immutable descriptor path, display name, and description; and
- endpoint readiness.

The target contains endpoint identity, attachment generation, instrument
identity, and Command path. An execution captures that target once before
awaiting the operation. A later inventory refresh may replace the projected
target but cannot retarget the in-flight execution.

Unchanged Command descriptors retain their persistent ViewModel instances.
Inventory refresh updates only the mutable target and endpoint readiness.
Changed immutable descriptor metadata still replaces the ViewModel.

`MainWindowViewModel` coordinates parameterless execution through the existing
`IDesktopRuntimeHostOperator`. It:

- requires the Desktop Runtime Host to be running;
- requires the endpoint to be ready;
- prevents overlapping execution of the same Command;
- passes a null argument explicitly;
- invokes the normalized operator exactly once;
- performs no automatic retry; and
- performs no optimistic Property mutation.

The persistent Command ViewModel projects:

- `Ready`;
- `Executing`;
- `Succeeded`;
- `Rejected`;
- `Failed`; and
- `Cancelled`.

Normalized stale-target, missing-target, unsupported-argument, and
endpoint-rejection outcomes are projected as rejected. Availability, endpoint
failure, timeout, and thrown exceptions are projected as failed. Cancellation
is projected separately.

An endpoint-provided return value is formatted invariantly and displayed after
success. Resulting device state changes remain authoritative only when they
arrive through the runtime cache and inventory refresh.

The Command card adds:

- `Execute Command`;
- current execution state;
- a concise result message; and
- an optional return value.

Automated tests cover:

- exact target capture;
- explicit null argument;
- successful return-value projection;
- normalized rejection;
- thrown failure;
- cancellation;
- single-flight protection;
- captured-target stability during attachment-generation replacement; and
- endpoint-readiness gating.

This increment supports only the parameterless semantics of the current HASE
`CommandDescriptor`. It introduces no Command argument editor, automatic retry,
optimistic Property update, numeric or string Property write, activity log,
persistent audit history, runtime contract change, transport change, protocol
change, or gRPC change.

