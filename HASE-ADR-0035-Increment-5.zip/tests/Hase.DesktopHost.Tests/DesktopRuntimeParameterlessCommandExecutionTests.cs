using Hase.Core.Domain.Identity;
using Hase.Core.Domain.Properties;
using Hase.DesktopHost.App.ViewModels;
using Hase.Runtime.Northbound;

namespace Hase.DesktopHost.Tests;

public sealed class DesktopRuntimeParameterlessCommandExecutionTests
{
    [Fact]
    public async Task ExecuteAsync_ShouldCaptureTargetPassNullAndProjectReturnValue()
    {
        RuntimeHostCommandTarget target =
            CreateTarget(
                "087f2821-f93e-4630-aa76-48d3ccbb62a6");
        var command =
            CreateCommandViewModel(
                target);
        var runtimeOperator =
            new RecordingOperator
            {
                ExecuteHandler =
                    (_, _, _) =>
                        Task.FromResult(
                            RuntimeHostCommandOperationResult.Successful(
                                true))
            };
        using MainWindowViewModel viewModel =
            CreateMainWindowViewModel(
                runtimeOperator);

        await viewModel.ExecuteParameterlessCommandAsync(
            command);

        Assert.Equal(
            1,
            runtimeOperator.ExecuteCount);
        Assert.Same(
            target,
            runtimeOperator.Target);
        Assert.Null(
            runtimeOperator.Argument);
        Assert.Equal(
            DesktopRuntimeCommandExecutionState.Succeeded,
            command.ExecutionState);
        Assert.True(
            command.HasReturnValue);
        Assert.Equal(
            "True",
            command.ReturnValue);
    }

    [Fact]
    public async Task ExecuteAsync_WithNormalizedRejection_ShouldProjectRejectedState()
    {
        var command =
            CreateCommandViewModel(
                CreateTarget(
                    "9e2e33c2-ccba-480f-bf2c-11302751758e"));
        var runtimeOperator =
            new RecordingOperator
            {
                ExecuteHandler =
                    (_, _, _) =>
                        Task.FromResult(
                            RuntimeHostCommandOperationResult.Failed(
                                RuntimeHostCommandOperationStatus
                                    .AttachmentNotCurrent,
                                "Attachment generation is stale."))
            };
        using MainWindowViewModel viewModel =
            CreateMainWindowViewModel(
                runtimeOperator);

        await viewModel.ExecuteParameterlessCommandAsync(
            command);

        Assert.Equal(
            DesktopRuntimeCommandExecutionState.Rejected,
            command.ExecutionState);
        Assert.Equal(
            "Attachment generation is stale.",
            command.ExecutionMessage);
    }

    [Fact]
    public async Task ExecuteAsync_WhenOperatorThrows_ShouldProjectFailedState()
    {
        var command =
            CreateCommandViewModel(
                CreateTarget(
                    "5025c8ba-9a48-49ba-a1a5-a10c739804dd"));
        var runtimeOperator =
            new RecordingOperator
            {
                ExecuteHandler =
                    (_, _, _) =>
                        Task.FromException<
                            RuntimeHostCommandOperationResult>(
                                new InvalidOperationException(
                                    "Operator unavailable."))
            };
        using MainWindowViewModel viewModel =
            CreateMainWindowViewModel(
                runtimeOperator);

        await viewModel.ExecuteParameterlessCommandAsync(
            command);

        Assert.Equal(
            DesktopRuntimeCommandExecutionState.Failed,
            command.ExecutionState);
        Assert.Equal(
            "Operator unavailable.",
            command.ExecutionMessage);
        Assert.Equal(
            1,
            runtimeOperator.ExecuteCount);
    }

    [Fact]
    public async Task ExecuteAsync_WhenCancelled_ShouldProjectCancelledState()
    {
        var command =
            CreateCommandViewModel(
                CreateTarget(
                    "4f6ed748-70dc-462c-a322-a85c5ab51e6c"));
        var runtimeOperator =
            new RecordingOperator
            {
                ExecuteHandler =
                    (_, _, cancellationToken) =>
                        Task.FromCanceled<
                            RuntimeHostCommandOperationResult>(
                                cancellationToken)
            };
        using MainWindowViewModel viewModel =
            CreateMainWindowViewModel(
                runtimeOperator);
        using var cancellationSource =
            new CancellationTokenSource();
        cancellationSource.Cancel();

        await viewModel.ExecuteParameterlessCommandAsync(
            command,
            cancellationSource.Token);

        Assert.Equal(
            DesktopRuntimeCommandExecutionState.Cancelled,
            command.ExecutionState);
        Assert.Equal(
            "Command cancelled.",
            command.ExecutionMessage);
    }

    [Fact]
    public async Task ExecuteAsync_WhileExecuting_ShouldNotStartOverlappingExecution()
    {
        var completion =
            new TaskCompletionSource<
                RuntimeHostCommandOperationResult>(
                    TaskCreationOptions.RunContinuationsAsynchronously);
        var command =
            CreateCommandViewModel(
                CreateTarget(
                    "c6437ab4-7e2a-4b90-8bd4-e5c22264073e"));
        var runtimeOperator =
            new RecordingOperator
            {
                ExecuteHandler =
                    (_, _, _) =>
                        completion.Task
            };
        using MainWindowViewModel viewModel =
            CreateMainWindowViewModel(
                runtimeOperator);

        Task firstExecution =
            viewModel.ExecuteParameterlessCommandAsync(
                command);
        await viewModel.ExecuteParameterlessCommandAsync(
            command);

        Assert.Equal(
            1,
            runtimeOperator.ExecuteCount);
        Assert.True(
            command.IsExecuting);

        completion.SetResult(
            RuntimeHostCommandOperationResult.Failed(
                RuntimeHostCommandOperationStatus.EndpointUnavailable));
        await firstExecution;

        Assert.Equal(
            DesktopRuntimeCommandExecutionState.Failed,
            command.ExecutionState);
    }

    [Fact]
    public async Task ExecuteAsync_WhenGenerationChangesInFlight_ShouldKeepCapturedTarget()
    {
        RuntimeHostCommandTarget originalTarget =
            CreateTarget(
                "21cfca79-7a7f-4609-84b0-90eae2b10955");
        RuntimeHostCommandTarget replacementTarget =
            CreateTarget(
                "f0cfc45e-0851-4f0a-a8da-79e37401db22");
        var completion =
            new TaskCompletionSource<
                RuntimeHostCommandOperationResult>(
                    TaskCreationOptions.RunContinuationsAsynchronously);
        var command =
            CreateCommandViewModel(
                originalTarget);
        var runtimeOperator =
            new RecordingOperator
            {
                ExecuteHandler =
                    (_, _, _) =>
                        completion.Task
            };
        using MainWindowViewModel viewModel =
            CreateMainWindowViewModel(
                runtimeOperator);

        Task execution =
            viewModel.ExecuteParameterlessCommandAsync(
                command);

        command.Update(
            CreateCommandSnapshot(
                replacementTarget,
                isEndpointReady: true));

        Assert.Same(
            originalTarget,
            runtimeOperator.Target);
        Assert.Same(
            replacementTarget,
            command.Target);

        completion.SetResult(
            RuntimeHostCommandOperationResult.Failed(
                RuntimeHostCommandOperationStatus.AttachmentNotCurrent));
        await execution;

        Assert.Equal(
            DesktopRuntimeCommandExecutionState.Rejected,
            command.ExecutionState);
    }

    [Fact]
    public async Task ExecuteAsync_WhenEndpointIsNotReady_ShouldNotCallOperator()
    {
        var command =
            new DesktopRuntimeCommandViewModel(
                CreateCommandSnapshot(
                    CreateTarget(
                        "ca868452-e2ee-4896-81a3-e50325c33e3c"),
                    isEndpointReady: false));
        var runtimeOperator =
            new RecordingOperator();
        using MainWindowViewModel viewModel =
            CreateMainWindowViewModel(
                runtimeOperator);

        await viewModel.ExecuteParameterlessCommandAsync(
            command);

        Assert.Equal(
            0,
            runtimeOperator.ExecuteCount);
        Assert.Equal(
            DesktopRuntimeCommandExecutionState.Ready,
            command.ExecutionState);
    }

    private static DesktopRuntimeCommandViewModel CreateCommandViewModel(
        RuntimeHostCommandTarget target) =>
        new(
            CreateCommandSnapshot(
                target,
                isEndpointReady: true));

    private static DesktopRuntimeCommandSnapshot CreateCommandSnapshot(
        RuntimeHostCommandTarget target,
        bool isEndpointReady) =>
        new(
            target,
            target.CommandPath.ToString(),
            "Toggle status LED",
            "Toggles the endpoint status LED.",
            isEndpointReady);

    private static RuntimeHostCommandTarget CreateTarget(
        string generation) =>
        new(
            new EndpointId("endpoint-1"),
            new RuntimeEndpointAttachmentGeneration(
                Guid.Parse(
                    generation)),
            new InstrumentId("instrument-1"),
            new DescriptorPath(
                "Controller",
                "Toggle"));

    private static MainWindowViewModel CreateMainWindowViewModel(
        IDesktopRuntimeHostOperator runtimeOperator)
    {
        var runtimeHost =
            new DesktopRuntimeHost(
                new StubBackend());
        var runtimeViewModel =
            new DesktopRuntimeHostViewModel(
                runtimeHost,
                new DesktopRuntimeHostShellInformation(
                    "composition",
                    "host",
                    "1.0",
                    "loopback",
                    "private"));
        runtimeHost.StartAsync()
            .GetAwaiter()
            .GetResult();
        var inventoryViewModel =
            new RuntimeInventoryViewModel(
                EmptyInventorySource.Instance);
        var endpointDetailsViewModel =
            new EndpointDetailsViewModel(
                inventoryViewModel);

        return new MainWindowViewModel(
            runtimeViewModel,
            inventoryViewModel,
            endpointDetailsViewModel,
            runtimeOperator);
    }

    private sealed class RecordingOperator
        : IDesktopRuntimeHostOperator
    {
        public Func<
            RuntimeHostCommandTarget,
            object?,
            CancellationToken,
            Task<RuntimeHostCommandOperationResult>>? ExecuteHandler
        {
            get;
            init;
        }

        public int ExecuteCount
        {
            get;
            private set;
        }

        public RuntimeHostCommandTarget? Target
        {
            get;
            private set;
        }

        public object? Argument
        {
            get;
            private set;
        }

        public Task<RuntimeHostPropertyOperationResult> WritePropertyAsync(
            RuntimeHostPropertyTarget target,
            object? requestedValue,
            CancellationToken cancellationToken = default) =>
            throw new NotSupportedException();

        public Task<RuntimeHostCommandOperationResult> ExecuteCommandAsync(
            RuntimeHostCommandTarget target,
            object? argument,
            CancellationToken cancellationToken = default)
        {
            ExecuteCount++;
            Target =
                target;
            Argument =
                argument;

            return ExecuteHandler?.Invoke(
                    target,
                    argument,
                    cancellationToken)
                ?? Task.FromResult(
                    RuntimeHostCommandOperationResult.Failed(
                        RuntimeHostCommandOperationStatus
                            .EndpointUnavailable));
        }
    }

    private sealed class StubBackend
        : IDesktopRuntimeHostBackend
    {
        public Task StartAsync(
            CancellationToken cancellationToken) =>
            Task.CompletedTask;

        public Task StopAsync(
            CancellationToken cancellationToken) =>
            Task.CompletedTask;
    }

    private sealed class EmptyInventorySource
        : IDesktopRuntimeHostInventorySource
    {
        public static EmptyInventorySource Instance
        {
            get;
        } =
            new();

        public IReadOnlyList<DesktopRuntimeEndpointSnapshot> Capture() =>
            [];
    }
}
