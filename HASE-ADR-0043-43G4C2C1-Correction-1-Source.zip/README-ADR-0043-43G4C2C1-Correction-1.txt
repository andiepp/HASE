HASE ADR-0043 Increment 43G4C2C1 Correction 1 source overlay.
Baseline: uncommitted 43G4C2C1 with 4,373 passing tests.
Apply over the repository root, build Release, and run the full suite.
Expected result: 4,373 tests passed.
The correction updates physical C-020 validation for both LED and A0 Properties.
